package com.example.collegeapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class Marks_S extends AppCompatActivity {
    TextView t1,t2,t3,t4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_marks_s);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        t1=(TextView)findViewById(R.id.sub1) ;
        t2=(TextView)findViewById(R.id.sub2) ;
        t3=(TextView)findViewById(R.id.sub3) ;
        t4=(TextView)findViewById(R.id.total);
        String user = getIntent().getStringExtra("rno");
        DatabaseReference databaseReference = FirebaseDatabase.getInstance().getReference("Students");

        databaseReference.child(user).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Assuming the student has a "name" field
                    String s1 = snapshot.child("s1").getValue(String.class);
                    assert s1 != null;
                    int sub1 = Integer.parseInt(s1);
                    t1.setText("Computer Networks: " + s1);

                    String s2 = snapshot.child("s2").getValue(String.class);
                    assert s2 != null;
                    int sub2 = Integer.parseInt(s2);
                    t2.setText( "Design And Analysis Of Algorithms: " + s2);

                    String s3 = snapshot.child("s3").getValue(String.class);
                    assert s3 != null;
                    int sub3 = Integer.parseInt(s3);
                    t3.setText("Programming Skill Development: " + s3);

                    int total=(sub1+sub2+sub3)/3;
                    t4.setText("Percentage:"+total+"%");

                } else {
                    t1.setText("Student not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseError", error.getMessage());
                t1.setText("Failed to load student information");
            }
        });



    }
}