package com.example.collegeapp;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Marks_T extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_marks_t);

        LinearLayout container = findViewById(R.id.container);

        // Create a single Spinner for the subjects
        Spinner spinner = new Spinner(Marks_T.this);
        String[] subjects = {"CN", "DAA", "PSDL"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(Marks_T.this, android.R.layout.simple_spinner_item, subjects);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
        spinner.setPadding(32, 120, 32, 80);
        // Add the Spinner to the container (before iterating through students)
        container.addView(spinner);

        // Firebase database reference
        DatabaseReference studentsRef = FirebaseDatabase.getInstance().getReference("Students");

        // Fetch data from Firebase
        studentsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    int i = 1; // Counter for buttons and TextViews
                    for (DataSnapshot studentSnapshot : dataSnapshot.getChildren()) {
                        String studentName = studentSnapshot.child("name").getValue(String.class);

                        // Create a horizontal LinearLayout for each row
                        LinearLayout rowLayout = new LinearLayout(Marks_T.this);
                        rowLayout.setOrientation(LinearLayout.HORIZONTAL);
                        rowLayout.setLayoutParams(new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        ));

                        // Create a TextView for the student name
                        TextView textView = new TextView(Marks_T.this);
                        textView.setText(studentName != null ? studentName : "Student " + i);
                        textView.setTextSize(20);
                        textView.setPadding(10, 10, 10, 10);
                        textView.setLayoutParams(new LinearLayout.LayoutParams(
                                0,
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                1.0f // Weight to allocate space proportionally
                        ));

                        // Add the TextView to the row layout
                        rowLayout.addView(textView);

                        // Create an EditText for user input
                        EditText editText = new EditText(Marks_T.this);
                        editText.setHint("Enter marks");
                        editText.setTextSize(20);
                        editText.setPadding(10, 10, 10, 10);
                        editText.setLayoutParams(new LinearLayout.LayoutParams(
                                0,
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                1.0f // Weight to allocate space proportionally
                        ));

                        // Add the EditText to the row layout
                        rowLayout.addView(editText);

                        // Create a Button for submitting
                        Button button = new Button(Marks_T.this);
                        button.setText("Submit");
                        button.setBackgroundColor(Color.parseColor("#6D77FB"));
                        button.setTextColor(Color.WHITE);
                        int currentIndex = i; // Capture the current index for click handling
                            button.setOnClickListener(new View.OnClickListener() {
                                @Override
                                public void onClick(View v) {
                                    String enteredText = editText.getText().toString();
                                    String selectedSubject = spinner.getSelectedItem().toString();
                                    if (!enteredText.isEmpty()) {
                                        updateDB(enteredText, selectedSubject);
                                    } else {
                                        textView.setText("No marks entered for " + studentName);
                                    }
                                }

                                private void updateDB(String marks, String subject) {
                                    DatabaseReference myRef = FirebaseDatabase.getInstance().getReference("Students");

                                    // Assuming the student's rollNo or other unique identifier is available
                                    Query query = myRef.orderByChild("name").equalTo(studentName);  // Query by the student's name

                                    query.addListenerForSingleValueEvent(new ValueEventListener() {
                                        @Override
                                        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                                            if (dataSnapshot.exists()) {
                                                for (DataSnapshot snapshot : dataSnapshot.getChildren()) {
                                                    String key = snapshot.getKey();
                                                    if (key != null) {
                                                        // Map the subject dynamically
                                                        String fieldToUpdate = "";
                                                        switch (subject) {
                                                            case "CN":
                                                                fieldToUpdate = "s1";
                                                                break;
                                                            case "DAA":
                                                                fieldToUpdate = "s2";
                                                                break;
                                                            case "PSDL":
                                                                fieldToUpdate = "s3";
                                                                break;
                                                        }

                                                        // Create a map to update the subject mark
                                                        HashMap<String, Object> updates = new HashMap<>();
                                                        updates.put(fieldToUpdate, marks);

                                                        myRef.child(key).updateChildren(updates)
                                                                .addOnCompleteListener(task -> {
                                                                    if (task.isSuccessful()) {
                                                                        Toast.makeText(Marks_T.this, "Marks updated successfully!", Toast.LENGTH_SHORT).show();
                                                                    } else {
                                                                        Toast.makeText(Marks_T.this, "Marks update failed!", Toast.LENGTH_SHORT).show();
                                                                    }
                                                                });
                                                    }
                                                }
                                            } else {
                                                Toast.makeText(Marks_T.this, "No record found with the specified student name!", Toast.LENGTH_SHORT).show();
                                            }
                                        }

                                        @Override
                                        public void onCancelled(@NonNull DatabaseError databaseError) {
                                            Toast.makeText(Marks_T.this, "Error: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
                                        }
                                    });
                                }

                                ///ghfhdtdrsxrfd
                            });
                        button.setLayoutParams(new LinearLayout.LayoutParams(
                                0,
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                0.5f // Adjust weight as needed
                        ));

                        // Add the Button to the row layout
                        rowLayout.addView(button);

                        // Add the row layout to the container
                        container.addView(rowLayout);

                        // Create a divider line
                        View divider = new View(Marks_T.this);
                        divider.setLayoutParams(new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.MATCH_PARENT,
                                2 // Height of the divider
                        ));
                        divider.setBackgroundColor(getResources().getColor(android.R.color.darker_gray));

                        // Add the divider below the row
                        container.addView(divider);

                        i++; // Increment counter
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
                // Handle database error
                System.err.println("Error fetching data: " + databaseError.getMessage());
            }
        });
    }
}
