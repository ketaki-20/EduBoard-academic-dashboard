//package com.example.collegeapp;
//
//import android.os.Bundle;
//import android.util.Log;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
//
//import java.util.HashMap;
//
//public class Attendance_S extends AppCompatActivity {
//    TextView attendanceTextView,defaulter;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_attendance_s);
//
//        attendanceTextView = findViewById(R.id.attendanceTextView);
//        defaulter=findViewById(R.id.def_s);
//        // Get student roll number from intent
//        String userRollNo = getIntent().getStringExtra("rno");
//
//        // Reference to the Attendance collection in Firebase
//        DatabaseReference attendanceRef = FirebaseDatabase.getInstance().getReference("Attendance");
//
//        attendanceRef.addValueEventListener(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot snapshot) {
//                if (snapshot.exists()) {
//                    // HashMap to store subject attendance counts
//                    HashMap<String, Integer> attendanceCount = new HashMap<>();
//
//                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
//                        String name = childSnapshot.child("name").getValue(String.class);
//                        String roll = childSnapshot.child("rollNo").getValue(String.class);
//                        String subject = childSnapshot.child("subject").getValue(String.class);
//                        String attendance = childSnapshot.child("attendance").getValue(String.class);
//
//                        if (name != null && roll.equals(userRollNo) && subject != null) {
//                            // Initialize subject count if not already present
//                            if (!attendanceCount.containsKey(subject)) {
//                                Toast.makeText(Attendance_S.this, attendance, Toast.LENGTH_SHORT).show();
//                                attendanceCount.put(subject, 0);
//                            }
//
//                            // Increment count if attendance is "Present"
//                            if ("Present".equalsIgnoreCase(attendance)) {
//                                attendanceCount.put(subject, attendanceCount.get(subject) + 1);
//
//                            }
//                        }
//                    }
//
//                    // Build and display the attendance data
//                    StringBuilder attendanceData = new StringBuilder();
//                    for (String subject : attendanceCount.keySet()) {
//                        attendanceData.append(subject).append(": ").append(attendanceCount.get(subject)).append("\n");
//                    }
//
//                    if (attendanceData.length() > 0) {
//                        attendanceTextView.setText(attendanceData.toString());
//                    }
//                    else {
//                        attendanceTextView.setText("No attendance records found.");
//                    }
//                } else {
//                    attendanceTextView.setText("No data found.");
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError error) {
//                Log.e("FirebaseError", error.getMessage());
//                attendanceTextView.setText("Failed to load attendance data.");
//            }
//   });
//}
//}
package com.example.collegeapp;

import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Attendance_S extends AppCompatActivity {
    TextView attendanceTextView, defaulterTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_attendance_s);

        attendanceTextView = findViewById(R.id.attendanceTextView);
        defaulterTextView = findViewById(R.id.def_s);

        // Get student roll number from intent
        String userRollNo = getIntent().getStringExtra("rno");

        // Reference to the Attendance collection in Firebase
        DatabaseReference attendanceRef = FirebaseDatabase.getInstance().getReference("Attendance");

        attendanceRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // HashMaps to store attendance counts for each subject
                    HashMap<String, Integer> presentCounts = new HashMap<>();
                    HashMap<String, Integer> totalCounts = new HashMap<>();

                    // Iterate over attendance records in Firebase
                    for (DataSnapshot childSnapshot : snapshot.getChildren()) {
                        String roll = childSnapshot.child("rollNo").getValue(String.class);
                        String subject = childSnapshot.child("subject").getValue(String.class);
                        String attendance = childSnapshot.child("attendance").getValue(String.class);

                        // Only process records for the current student
                        if (roll != null && roll.equals(userRollNo) && subject != null) {
                            // Increment total attendance count for the subject
                            totalCounts.put(subject, totalCounts.getOrDefault(subject, 0) + 1);

                            // Increment present count if attendance is "Present"
                            if ("Present".equalsIgnoreCase(attendance)) {
                                presentCounts.put(subject, presentCounts.getOrDefault(subject, 0) + 1);
                            }
                        }
                    }

                    // Build and display the attendance data
                    StringBuilder attendanceData = new StringBuilder();
                    StringBuilder defaulterSubjects = new StringBuilder();

                    for (String subject : totalCounts.keySet()) {
                        int total = totalCounts.get(subject);
                        int present = presentCounts.getOrDefault(subject, 0);

                        // Calculate attendance percentage
                        double percentage = ((double) present / total) * 100;

                        // Append subject and attendance to attendance data
                        attendanceData.append(subject)
                                .append(": ")
                                .append(present)
                                .append("/")
                                .append(total)
                                .append(" (")
                                .append(String.format("%.2f", percentage))
                                .append("%)\n");

                        // Check if the student is a defaulter for this subject
                        if (percentage < 75) {
                            defaulterSubjects.append(subject).append("\n");
                        }
                    }

                    // Update the attendanceTextView with attendance data
                    if (attendanceData.length() > 0) {
                        attendanceTextView.setText(attendanceData.toString());
                    } else {
                        attendanceTextView.setText("No attendance records found.");
                    }

                    // Update the defaulterTextView based on defaulter subjects
                    if (defaulterSubjects.length() > 0) {
                        defaulterTextView.setText("You are in the defaulter list for subjects:\n" + defaulterSubjects.toString());
                    } else {
                        defaulterTextView.setText("You are not in any defaulter list! Good Job!");
                    }
                } else {
                    attendanceTextView.setText("No data found.");
                    defaulterTextView.setText("You are not in any defaulter list! Good Job!");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseError", error.getMessage());
                attendanceTextView.setText("Failed to load attendance data.");
                defaulterTextView.setText("Failed to load defaulter status.");
            }
   });
}
}