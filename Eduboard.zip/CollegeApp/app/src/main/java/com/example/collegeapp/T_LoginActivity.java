package com.example.collegeapp;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class T_LoginActivity extends AppCompatActivity {

    EditText username;
    EditText password;
    Button loginButton, signup;
    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tlogin);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        signup = findViewById(R.id.SignUpButton);

        // Initialize Firebase reference
        reference = FirebaseDatabase.getInstance().getReference("Teachers");

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String enteredId = username.getText().toString().trim();
                String enteredPassword = password.getText().toString().trim();

                if (!enteredId.isEmpty() && !enteredPassword.isEmpty()) {
                    authenticateUser(enteredId, enteredPassword);
                } else {
                    Toast.makeText(T_LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signup.setOnClickListener(view -> {
            Intent inext = new Intent(T_LoginActivity.this, T_SignUpActivity.class);
            startActivity(inext);
        });
    }

    public void authenticateUser(String id, String enteredPassword) {
        reference.child(id).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String dbPassword = snapshot.child("password").getValue(String.class);

                    if (dbPassword != null && dbPassword.equals(enteredPassword)) {
                        Toast.makeText(T_LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                        // Proceed to the next activity or main screen
                        startActivity(new Intent(T_LoginActivity.this, T_Window.class));
                    } else {
                        Toast.makeText(T_LoginActivity.this, "Incorrect Password!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(T_LoginActivity.this, "User doesn't exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(T_LoginActivity.this, "Database Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}
