package com.example.collegeapp;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class S_Window2 extends AppCompatActivity {
    TextView t1,t2,t3;
    Button marks,attendance;
    private DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_swindow2);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        String user = getIntent().getStringExtra("rno");

        marks=(Button)findViewById(R.id.marks);
        attendance=(Button)findViewById(R.id.attendance);
        t1=(TextView)findViewById(R.id.text_home) ;
        t2=(TextView)findViewById(R.id.heading) ;
        t3=(TextView)findViewById(R.id.rno_view) ;


        marks.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(S_Window2.this, Marks_S.class);
                intent.putExtra("rno", user);
                startActivity(intent);
            }
        });

        attendance.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(S_Window2.this, Attendance_S.class);
                intent.putExtra("rno", user);
                startActivity(intent);
            }
        });
        databaseReference = FirebaseDatabase.getInstance().getReference("Students");

        databaseReference.child(user).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    // Assuming the student has a "name" field
                    String studentName = snapshot.child("name").getValue(String.class);
                    t1.setText("Welcome " + studentName);

                    String rno = snapshot.child("rollNo").getValue(String.class);
                    t2.setText( rno);

                    String email = snapshot.child("email").getValue(String.class);
                    t3.setText(email);

                } else {
                    t1.setText("Student not found");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e("FirebaseError", error.getMessage());
                t1.setText("Failed to load student information");
            }
        });




    }
}