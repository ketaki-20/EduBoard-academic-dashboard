package com.example.collegeapp;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;


import com.example.collegeapp.Students;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.android.material.textfield.TextInputLayout;

public class S_SignUpActivity extends AppCompatActivity {

    private EditText rollNoField, nameField, departmentField, emailField, passwordField;
    private FirebaseDatabase db;
    private DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ssign_up);


        // Initialize form fields
        rollNoField = findViewById(R.id.roll_no);
        nameField = findViewById(R.id.name);
        departmentField = findViewById(R.id.department);
        emailField = findViewById(R.id.email);
        passwordField = findViewById(R.id.password);

        // Initialize Firebase Database
        db = FirebaseDatabase.getInstance();
        reference = db.getReference("Students");

        Button submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(view -> {
            if (validateForm()) {
                addStudentToDatabase();
            }
        });
    }

    private boolean validateForm() {
        String rollNo = rollNoField.getText().toString().trim();
        String name = nameField.getText().toString().trim();
        String department = departmentField.getText().toString().trim();
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (TextUtils.isEmpty(rollNo)) {
            rollNoField.setError("Roll number is required");
            rollNoField.requestFocus();
            return false;
        }
        if (!rollNo.matches("\\d+")) {
            rollNoField.setError("Roll number must be numeric");
            rollNoField.requestFocus();
            return false;
        }

        if (TextUtils.isEmpty(name)) {
            nameField.setError("Name is required");
            nameField.requestFocus();
            return false;
        }

        if (TextUtils.isEmpty(department)) {
            departmentField.setError("Department is required");
            departmentField.requestFocus();
            return false;
        }

        if (TextUtils.isEmpty(email)) {
            emailField.setError("Email is required");
            emailField.requestFocus();
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailField.setError("Enter a valid email address");
            emailField.requestFocus();
            return false;
        }

        if (TextUtils.isEmpty(password)) {
            passwordField.setError("Password is required");
            passwordField.requestFocus();
            return false;
        }
        if (password.length() < 6) {
            passwordField.setError("Password must be at least 6 characters long");
            passwordField.requestFocus();
            return false;
        }

        return true;
    }

    private void addStudentToDatabase() {
        String rollNo = rollNoField.getText().toString().trim();
        String name = nameField.getText().toString().trim();
        String department = departmentField.getText().toString().trim();
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        Students student = new Students(name, department, email, password, rollNo,"0","0","0");

        reference.child(rollNo).setValue(student).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(S_SignUpActivity.this, "Student added successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(S_SignUpActivity.this, "Failed to add student. Try again!", Toast.LENGTH_SHORT).show();
            }
   });
    }
}
