package com.example.collegeapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class T_SignUpActivity extends AppCompatActivity {
    private EditText id, nameField, emailField, passwordField,subjectField;
    private FirebaseDatabase db;
    private DatabaseReference reference;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_tsign_up);

        id = findViewById(R.id.t_id);
        nameField = findViewById(R.id.name);
        emailField = findViewById(R.id.email);
        passwordField = findViewById(R.id.password);
        subjectField=findViewById(R.id.subject);


        // Initialize Firebase Database
        db = FirebaseDatabase.getInstance();
        reference = db.getReference("Teachers");

        Button submitButton = findViewById(R.id.submitButton);
        submitButton.setOnClickListener(view -> {
            if (validateForm()) {
                addTeacherToDatabase();
            }
        });
    }

    private boolean validateForm() {
        String rollNo = id.getText().toString().trim();
        String name = nameField.getText().toString().trim();
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();

        if (TextUtils.isEmpty(rollNo)) {
            id.setError("Roll number is required");
            id.requestFocus();
            return false;
        }
        if (!rollNo.matches("\\d+")) {
            id.setError("Roll number must be numeric");
            id.requestFocus();
            return false;
        }

        if (TextUtils.isEmpty(name)) {
            nameField.setError("Name is required");
            nameField.requestFocus();
            return false;
        }

        if (TextUtils.isEmpty(email)) {
            emailField.setError("Email is required");
            emailField.requestFocus();
            return false;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            emailField.setError("Enter a valid email address");
            emailField.requestFocus();
            return false;
        }

        if (TextUtils.isEmpty(password)) {
            passwordField.setError("Password is required");
            passwordField.requestFocus();
            return false;
        }
        if (password.length() < 6) {
            passwordField.setError("Password must be at least 6 characters long");
            passwordField.requestFocus();
            return false;
        }

        return true;
    }

    private void addTeacherToDatabase() {
        String rollNo = id.getText().toString().trim();
        String name = nameField.getText().toString().trim();
        String department = id.getText().toString().trim();
        String email = emailField.getText().toString().trim();
        String password = passwordField.getText().toString().trim();
        String subject = subjectField.getText().toString().trim();

        Teachers teacher = new Teachers(name, email, password, Integer.parseInt(rollNo),subject);

        reference.child(rollNo).setValue(teacher).addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                Toast.makeText(T_SignUpActivity.this, "Teacher added successfully!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(T_SignUpActivity.this, "Failed to add teacher. Try again!", Toast.LENGTH_SHORT).show();
            }
        });
    }
}