package com.example.collegeapp;
public class Students {

    String name, department, email, password;
    String rollNo,sub1,sub2,sub3;

    // Default constructor
    public Students() {
    }

    // Parameterized constructor
    public Students(String name, String department, String email, String password, String rollNo ,String sub1,String sub2,String sub3) {
        this.name = name;
        this.department = department;
        this.email = email;
        this.password = password;
        this.rollNo = rollNo;
        this.sub1=sub1;
        this.sub2=sub2;
        this.sub3=sub3;
    }

    // Getter and Setter methods
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        this.rollNo =rollNo;
    }

    public String getS1() {
        return sub1;
    }

    public void setS1(String sub1) {
        this.sub1 =sub1;
    }

    public String getS2() {
        return sub2;
    }

    public void setS2(String sub2) {
        this.sub2 =sub2;
    }

    public String getS3() {
        return sub3;
    }

    public void setS3(String sub3) {
        this.sub3 =sub3;
    }
}
