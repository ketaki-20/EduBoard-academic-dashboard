package com.example.collegeapp;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;

public class Defaulter extends AppCompatActivity {

    private Spinner subjectSpinner;
    private Button generateDefaulterListButton;
    private LinearLayout defaulterContainer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_defaulter);

        // Initialize views
        subjectSpinner = findViewById(R.id.subjectSpinner);
        generateDefaulterListButton = findViewById(R.id.generateDefaulterListButton);
        defaulterContainer = findViewById(R.id.defaulterContainer);

        // Populate the spinner with subjects
        String[] subjects = {"CN", "DAA", "PSDL"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, subjects);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        subjectSpinner.setAdapter(adapter);

        // Set up the button click listener
        generateDefaulterListButton.setOnClickListener(v -> {
            String selectedSubject = subjectSpinner.getSelectedItem().toString();
            generateDefaulterList(selectedSubject);
        });
    }

    private void generateDefaulterList(String subject) {
        defaulterContainer.removeAllViews(); // Clear previous results

        DatabaseReference attendanceRef = FirebaseDatabase.getInstance().getReference("Attendance");

        HashMap<String, Integer> presentCounts = new HashMap<>();
        HashMap<String, Integer> totalCounts = new HashMap<>();

        // Fetch Attendance Data
        attendanceRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    for (DataSnapshot record : snapshot.getChildren()) {
                        String rollNo = record.child("rollNo").getValue(String.class);
                        String subjectName = record.child("subject").getValue(String.class);
                        String attendance = record.child("attendance").getValue(String.class);

                        if (rollNo != null && subjectName != null && subjectName.equals(subject)) {
                            // Initialize counts for each roll number
                            totalCounts.put(rollNo, totalCounts.getOrDefault(rollNo, 0) + 1);
                            if ("Present".equalsIgnoreCase(attendance)) {
                                presentCounts.put(rollNo, presentCounts.getOrDefault(rollNo, 0) + 1);
                            }
                        }
                    }

                    // Calculate Attendance Percentage and Add Defaulters
                    for (String rollNo : totalCounts.keySet()) {
                        int total = totalCounts.get(rollNo);
                        int present = presentCounts.getOrDefault(rollNo, 0);

                        // Calculate attendance percentage
                        double percentage = ((double) present / total) * 100;

                        // Add to defaulter list if attendance is less than 75%
                        if (percentage < 75) {
                            addRollNoToDefaulterList(rollNo, percentage);
                        }
                    }

                    if (defaulterContainer.getChildCount() == 0) {
                        addMessageToDefaulterList("No defaulters found for the selected subject.");
                    }
                } else {
                    Toast.makeText(Defaulter.this, "No attendance records found.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(Defaulter.this, "Failed to fetch attendance data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addRollNoToDefaulterList(String rollNo, double percentage) {
        TextView defaulterText = new TextView(this);
        defaulterText.setText("Roll No: " + rollNo + " - " + String.format("%.2f", percentage) + "%");
        defaulterText.setPadding(16, 16, 16, 16);
        defaulterContainer.addView(defaulterText);
    }

    private void addMessageToDefaulterList(String message) {
        TextView messageText = new TextView(this);
        messageText.setText(message);
        messageText.setPadding(16, 16, 16, 16);
        defaulterContainer.addView(messageText);
}
}