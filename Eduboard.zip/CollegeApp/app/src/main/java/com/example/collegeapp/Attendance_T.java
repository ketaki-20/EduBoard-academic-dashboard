//package com.example.collegeapp;
//
//import android.app.DatePickerDialog;
//import android.graphics.Color;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.ArrayAdapter;
//import android.widget.Button;
//import android.widget.CheckBox;
//import android.widget.DatePicker;
//import android.widget.EditText;
//import android.widget.LinearLayout;
//import android.widget.Spinner;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import androidx.activity.EdgeToEdge;
//import androidx.annotation.NonNull;
//import androidx.appcompat.app.AppCompatActivity;
//
//import com.google.firebase.database.DataSnapshot;
//import com.google.firebase.database.DatabaseError;
//import com.google.firebase.database.DatabaseReference;
//import com.google.firebase.database.FirebaseDatabase;
//import com.google.firebase.database.ValueEventListener;
//
//import java.util.ArrayList;
//import java.util.Calendar;
//import java.util.HashMap;
//import java.util.List;
//
//public class Attendance_T extends AppCompatActivity {
//
//    Button datePickerButton;
//    String selectedDate = "";
//    List<HashMap<String, String>> attendanceData = new ArrayList<>();
//    LinearLayout container;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        EdgeToEdge.enable(this);
//        setContentView(R.layout.activity_attendance_t);
//
//        container = findViewById(R.id.container);
//        datePickerButton = findViewById(R.id.datePickerButton);
//
//        // Date Picker
//        datePickerButton.setOnClickListener(v -> {
//            final Calendar c = Calendar.getInstance();
//            int year = c.get(Calendar.YEAR);
//            int month = c.get(Calendar.MONTH);
//            int day = c.get(Calendar.DAY_OF_MONTH);
//
//            DatePickerDialog datePickerDialog = new DatePickerDialog(
//                    Attendance_T.this,
//                    (view, year1, monthOfYear, dayOfMonth) -> {
//                        selectedDate = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year1;
//                        Toast.makeText(Attendance_T.this, "Date Selected: " + selectedDate, Toast.LENGTH_SHORT).show();
//                    },
//                    year, month, day);
//            datePickerDialog.show();
//        });
//
//        // Create a Spinner for the subjects
//        Spinner spinner = new Spinner(Attendance_T.this);
//        String[] subjects = {"CN", "DAA", "PSDL"};
//        ArrayAdapter<String> adapter = new ArrayAdapter<>(Attendance_T.this, android.R.layout.simple_spinner_item, subjects);
//        adapter.setDropDownViewResource(R.layout.spinner_item);
//        spinner.setAdapter(adapter);
//
//        // Add the Spinner to the container (before iterating through students)
//        container.addView(spinner);
//
//        // Firebase database reference
//        DatabaseReference studentsRef = FirebaseDatabase.getInstance().getReference("Students");
//
//        // Fetch data from Firebase
//        studentsRef.addListenerForSingleValueEvent(new ValueEventListener() {
//            @Override
//            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
//                if (dataSnapshot.exists()) {
//                    for (DataSnapshot studentSnapshot : dataSnapshot.getChildren()) {
//                        String studentName = studentSnapshot.child("name").getValue(String.class);
//                        String studentR= studentSnapshot.child("rollNo").getValue(String.class);
//
//                        // Create a horizontal LinearLayout for each student row
//                        LinearLayout rowLayout = new LinearLayout(Attendance_T.this);
//                        rowLayout.setOrientation(LinearLayout.HORIZONTAL);
//
//                        // TextView for student name
//                        TextView textView = new TextView(Attendance_T.this);
//                        textView.setText(studentName != null ? studentName : "Unknown Student");
//                        textView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
//                        rowLayout.addView(textView);
//
//                        // CheckBox for attendance
//                        CheckBox attendanceCheckBox = new CheckBox(Attendance_T.this);
//                        attendanceCheckBox.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
//                        rowLayout.addView(attendanceCheckBox);
//
//                        // Add rowLayout to the container
//                        container.addView(rowLayout);
//
//                        // Collect data for submission later
//                        HashMap<String, String> studentData = new HashMap<>();
//                        studentData.put("name", studentName != null ? studentName : "Unknown Student");
//                        studentData.put("attendance", "Absent"); // Default to "Absent"
//                        studentData.put("rollNo", studentR != null ? studentR : "");
//                        attendanceCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
//                            studentData.put("attendance", isChecked ? "Present" : "Absent");
//                        });
//
//                        attendanceData.add(studentData);
//                    }
//
//                    // Add the Submit button at the end
//                    Button submitButton = new Button(Attendance_T.this);
//                    submitButton.setText("Submit");
//                    submitButton.setBackgroundColor(Color.parseColor("#6D77FB"));
//                    submitButton.setTextColor(Color.WHITE);
//                    submitButton.setOnClickListener(v -> {
//                        String selectedSubject = spinner.getSelectedItem().toString();
//                        if (selectedDate.isEmpty()) {
//                            Toast.makeText(Attendance_T.this, "Please select a date!", Toast.LENGTH_SHORT).show();
//                            return;
//                        }
//                        // Push data to Firebase
//                        DatabaseReference attendanceRef = FirebaseDatabase.getInstance().getReference("Attendance");
//                        for (HashMap<String, String> student : attendanceData) {
//                            student.put("subject", selectedSubject);
//                            student.put("date", selectedDate);
//                            attendanceRef.push().setValue(student);
//                        }
//                        Toast.makeText(Attendance_T.this, "Attendance submitted successfully!", Toast.LENGTH_SHORT).show();
//                    });
//                    container.addView(submitButton);
//                }
//            }
//
//            @Override
//            public void onCancelled(@NonNull DatabaseError databaseError) {
//                Toast.makeText(Attendance_T.this, "Error fetching students: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
//            }
//        });
//    }
//}

package com.example.collegeapp;

import android.app.DatePickerDialog;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

public class Attendance_T extends AppCompatActivity {

    Button datePickerButton;
    String selectedDate = "";
    List<HashMap<String, String>> attendanceData = new ArrayList<>();
    LinearLayout container;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_attendance_t);

        container = findViewById(R.id.container);
        datePickerButton = findViewById(R.id.datePickerButton);

        // Date Picker
        datePickerButton.setOnClickListener(v -> {
            final Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    Attendance_T.this,
                    (view, year1, monthOfYear, dayOfMonth) -> {
                        selectedDate = dayOfMonth + "-" + (monthOfYear + 1) + "-" + year1;
                        Toast.makeText(Attendance_T.this, "Date Selected: " + selectedDate, Toast.LENGTH_SHORT).show();
                    },
                    year, month, day);
            datePickerDialog.show();
        });

        // Create a Spinner for the subjects
        Spinner spinner = new Spinner(Attendance_T.this);
        String[] subjects = {"CN", "DAA", "PSDL"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(Attendance_T.this, android.R.layout.simple_spinner_item, subjects);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);

        // Add the Spinner to the container (before iterating through students)
        container.addView(spinner);

        // Firebase database reference
        DatabaseReference studentsRef = FirebaseDatabase.getInstance().getReference("Students");

        // Fetch data from Firebase
        studentsRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()) {
                    int srNo = 1; // Initialize Sr. No counter
                    for (DataSnapshot studentSnapshot : dataSnapshot.getChildren()) {
                        String studentName = studentSnapshot.child("name").getValue(String.class);
                        String studentRollNo = studentSnapshot.child("rollNo").getValue(String.class);

                        // Create a horizontal LinearLayout for each student row
                        LinearLayout rowLayout = new LinearLayout(Attendance_T.this);
                        rowLayout.setOrientation(LinearLayout.HORIZONTAL);

                        // TextView for Sr. No
                        TextView srNoTextView = new TextView(Attendance_T.this);
                        srNoTextView.setText(String.valueOf(srNo++)); // Increment Sr. No
                        srNoTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                        rowLayout.addView(srNoTextView);

                        // TextView for Roll No
                        TextView rollNoTextView = new TextView(Attendance_T.this);
                        rollNoTextView.setText(studentRollNo != null ? studentRollNo : "Unknown RollNo");
                        rollNoTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                        rowLayout.addView(rollNoTextView);

                        // TextView for student name
                        TextView nameTextView = new TextView(Attendance_T.this);
                        nameTextView.setText(studentName != null ? studentName : "Unknown Student");
                        nameTextView.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 2f));
                        rowLayout.addView(nameTextView);

                        // CheckBox for attendance
                        CheckBox attendanceCheckBox = new CheckBox(Attendance_T.this);
                        attendanceCheckBox.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
                        rowLayout.addView(attendanceCheckBox);

                        // Add rowLayout to the container
                        container.addView(rowLayout);

                        // Collect data for submission later
                        HashMap<String, String> studentData = new HashMap<>();
                        studentData.put("name", studentName != null ? studentName : "Unknown Student");
                        studentData.put("attendance", "Absent"); // Default to "Absent"
                        studentData.put("rollNo", studentRollNo != null ? studentRollNo : "");
                        attendanceCheckBox.setOnCheckedChangeListener((buttonView, isChecked) -> {
                            studentData.put("attendance", isChecked ? "Present" : "Absent");
                        });

                        attendanceData.add(studentData);
                    }

                    // Add the Submit button at the end
                    Button submitButton = new Button(Attendance_T.this);
                    submitButton.setText("Submit");
                    submitButton.setBackgroundColor(Color.parseColor("#6D77FB"));
                    submitButton.setTextColor(Color.WHITE);
                    submitButton.setOnClickListener(v -> {
                        String selectedSubject = spinner.getSelectedItem().toString();
                        if (selectedDate.isEmpty()) {
                            Toast.makeText(Attendance_T.this, "Please select a date!", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        // Push data to Firebase
                        DatabaseReference attendanceRef = FirebaseDatabase.getInstance().getReference("Attendance");
                        for (HashMap<String, String> student : attendanceData) {
                            student.put("subject", selectedSubject);
                            student.put("date", selectedDate);
                            attendanceRef.push().setValue(student);
                        }
                        Toast.makeText(Attendance_T.this, "Attendance submitted successfully!", Toast.LENGTH_SHORT).show();
                    });
                    container.addView(submitButton);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {
                Toast.makeText(Attendance_T.this, "Error fetching students: " + databaseError.getMessage(), Toast.LENGTH_SHORT).show();
            }
   });
}
}