//package com.example.collegeapp;
//
//import androidx.appcompat.app.AppCompatActivity;
//
//import android.content.Intent;
//import android.os.Bundle;
//import android.view.View;
//import android.widget.Button;
//import android.widget.EditText;
//import android.widget.Toast;
//
//public class S_LoginActivity extends AppCompatActivity {
//
//    EditText username;
//    EditText password;
//    Button loginButton,signup;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_slogin); // Ensure this matches your XML file name
//
//        // Initialize views AFTER setContentView
//        username = findViewById(R.id.username);
//        password = findViewById(R.id.password);
//        loginButton = findViewById(R.id.loginButton);
//        signup=findViewById(R.id.SignUpButton);
//        loginButton.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//
//                if (username.getText().toString().equals("user") && password.getText().toString().equals("1234")) {
//                    Toast.makeText(S_LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
//                } else {
//                    Toast.makeText(S_LoginActivity.this, "Login Failed!", Toast.LENGTH_SHORT).show();
//                }
//            }
//        });
//        signup.setOnClickListener(view -> {
//            Intent inext = new Intent(S_LoginActivity.this,S_SignUpActivity.class);
//            startActivity(inext);
//        });
//    }
//}
package com.example.collegeapp;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class S_LoginActivity extends AppCompatActivity {

    EditText username;
    EditText password;
    Button loginButton, signup;

    DatabaseReference reference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_slogin);

        username = findViewById(R.id.username);
        password = findViewById(R.id.password);
        loginButton = findViewById(R.id.loginButton);
        signup = findViewById(R.id.SignUpButton);

        // Initialize Firebase reference
        reference = FirebaseDatabase.getInstance().getReference("Students");

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String enteredRollNo = username.getText().toString().trim();
                String enteredPassword = password.getText().toString().trim();

                if (!enteredRollNo.isEmpty() && !enteredPassword.isEmpty()) {
                    authenticateUser(enteredRollNo, enteredPassword);
                } else {
                    Toast.makeText(S_LoginActivity.this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
                }
            }
        });

        signup.setOnClickListener(view -> {
            Intent inext = new Intent(S_LoginActivity.this, S_SignUpActivity.class);
            startActivity(inext);
        });
    }

    public void authenticateUser(String rollNo, String enteredPassword) {
        reference.child(rollNo).addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    String dbPassword = snapshot.child("password").getValue(String.class);

                    if (dbPassword != null && dbPassword.equals(enteredPassword)) {
                        Toast.makeText(S_LoginActivity.this, "Login Successful!", Toast.LENGTH_SHORT).show();
                        // Proceed to the next activity or main screen
                        Intent intent= new Intent(S_LoginActivity.this, S_Window2.class);
                        intent.putExtra("rno", rollNo);
                        startActivity(intent);
                    } else {
                        Toast.makeText(S_LoginActivity.this, "Incorrect Password!", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(S_LoginActivity.this, "User doesn't exist", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(S_LoginActivity.this, "Database Error: " + error.getMessage(), Toast.LENGTH_SHORT).show();
            }
   });
    }
}
